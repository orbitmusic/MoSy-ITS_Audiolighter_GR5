//Own Code Begin
package com.gauravk.audiovisualizersample.ui;


import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothManager;
import android.content.Context;


public class CreateBluetoothConnection {

    public Context context;
    public BluetoothAdapter bluetoothAdapter;
    public static BluetoothLeService bluetoothLeService;

    public CreateBluetoothConnection(Context context){
        this.context=context;
    }
    public void setupBluetoothConnection(){
        System.out.println("Setting up Bluetooth Connection");
        BluetoothManager bluetoothManager = (BluetoothManager) context.getSystemService(Context.BLUETOOTH_SERVICE);
        bluetoothAdapter = bluetoothManager.getAdapter();
        bluetoothLeService = new BluetoothLeService(bluetoothManager);
        bluetoothLeService.initialize();
        bluetoothLeService.write("Bluetooth Service successfully established!");

    }


}
//Own Code End